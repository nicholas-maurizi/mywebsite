library(pracma)
library(pryr)
library(upscaler)
library(dplyr)
library(ggplot2)
library(patchwork)
# add_folder()


####FOR LOOP IN PLACE ----
i=2016

name <- list.files(path="NEON_count-landbird", pattern=paste(i),include.dirs = TRUE)

data <- list.files(path=paste("NEON_count-landbird/",name,sep=""),pattern="countdata")

birddata <- read.csv(paste("NEON_count-landbird/",name,"/",data,sep=""))

birddata <- select(birddata, taxonID, scientificName)
birddata <- mutate(birddata, year = paste(i))
gooddata <- mutate(birddata, count = 1:length(birddata$year))


if(i==2015){
  bigdata <- gooddata
}
if(i>=2016){
bigdata <- rbind(bigdata,gooddata)
}
head(bigdata)
tail(bigdata)


#TRY AS A LOOP



### goodloop ----
for(i in 2015:2023){
  name <- list.files(path="NEON_count-landbird", pattern=paste(i,"-06",sep=""),include.dirs = TRUE)

  d <- list.files(path=paste("NEON_count-landbird/",name,sep=""),pattern="countdata")

  birddata <- read.csv(paste("NEON_count-landbird/",name,"/",d,sep=""))

  birddata <- select(birddata, taxonID, scientificName)
  gooddata <- mutate(birddata, year = paste(i))

  species <- gooddata%>%count(scientificName)


  if(i==2015){
    bigdata <- gooddata
    richness <- c()
    abundance <- c()
    summaries <- data.frame(matrix(ncol=4,nrow=0))
  }

  richness <- append(richness,length(species$scientificName))
  abundance <- append(abundance,length(gooddata$year))
  summaries <- rbind(summaries, c(d,richness[(i-2014)],abundance[(i-2014)],i))

  if(i>=2016){
    bigdata <- rbind(bigdata,gooddata)
  }

  if(i==2023){
    colnames(summaries) <- c('file','Richness','Abundance','Year')
    lmspecies <- lm(richness~abundance, data=summaries)
    print(summary(lmspecies))

    p1 <- ggplot(summaries,aes(x=abundance,y=richness)) + geom_point() + geom_smooth(method = "lm", se = FALSE, color = "slateblue3") + theme_minimal()

    p2 <- ggplot(summaries, aes(abundance)) + geom_histogram(bins=10, color = "black", fill = "lightblue1") + theme_minimal()

    p3 <- ggplot(summaries, aes(richness)) + geom_histogram(bins=10, color = "black", fill = "lightgoldenrodyellow") + theme_minimal()

    print(p1/(p2 | p3) + plot_annotation(tag_levels ="a", title = "Scatterplot of species abundance vs. richness and their respective histograms"))
  }
}
#####messing around----
build_function("lineardf")

View(iris)
iris <- iris




a <- sum(bigdata$year=="2023") #to find abundance for a given year
a

b <- bigdata%>%
  filter(year=="2023")%>%
  count(scientificName)
b
c <- nrow(b)
c
filter(bigdata, year=="2024")
#####builds-----
build_function("statsbyyear")
build_function("scatterandhistos")



a <- c(2014:2019)
i <- 3


b <- bigdata%>%
  filter(year==(a[i]))%>%
  count(scientificName)
b <- nrow(b)



###applying function ----
for(i in 2015:2023){
  name <- list.files(path="NEON_count-landbird",
                     pattern=paste(i,"-06",sep=""),
                     include.dirs = TRUE)

  d <- list.files(path=paste("NEON_count-landbird/",name,sep=""),pattern="countdata")

  birddata <- read.csv(paste("NEON_count-landbird/",name,"/",d,sep=""))

  birddata <- select(birddata, taxonID, scientificName)
  gooddata <- mutate(birddata, year = paste(i))

  if(i==2015){
    bigdata <- gooddata
  } else {
    bigdata <- rbind(bigdata,gooddata)
  }

  if(i==2023){
    sums <- statsbygroup(data = bigdata, species = "scientificName", group = "year")
    scatterandhistos(data = sums, x = "Richness", y = "Abundance", bins = 8)
    l <- lineardf(data = sums, x = "Richness", y = "Abundance")
  }
}




