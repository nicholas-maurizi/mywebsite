### Final script
#Scrap work can be found in "strategic coding.R"

# there are three required functions for this to work:
# 1. lineardf()
# 2. scatterandhistos()
# 3. statsbygroup()
# all three can be found in the functions folder

library(dplyr)
library(ggplot2)
library(patchwork)

for(i in 2015:2023){
  name <- list.files(path="NEON_count-landbird",
                     pattern=paste(i,"-06",sep=""),
                     include.dirs = TRUE)

  d <- list.files(path=paste("NEON_count-landbird/",name,sep=""),pattern="countdata")

  birddata <- read.csv(paste("NEON_count-landbird/",name,"/",d,sep=""))

  birddata <- select(birddata, taxonID, scientificName)
  gooddata <- mutate(birddata, year = paste(i))

  if(i==2015){
    bigdata <- gooddata
  } else {
    bigdata <- rbind(bigdata,gooddata)
  }

  if(i==2023){
    sums <- statsbygroup(data = bigdata, species = "scientificName", group = "year")
    scatterandhistos(data = sums, x = "Richness", y = "Abundance", bins = 8)
    l <- lineardf(data = sums, x = "Richness", y = "Abundance")
  }
}
