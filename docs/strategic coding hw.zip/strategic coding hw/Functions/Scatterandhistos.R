# --------------------------------------
# FUNCTION scatterandhistos
# required packages: ggolot2, patchwork
# description: builds a scatterplot with linear regression line and accompanying histograms of each group. Displays as one labeled figure
# inputs: a data framne with two continuous variables (x and y), optionally a customization of bins for histograms
# outputs: one figure showing scatterplot and histograms labeled with title and 'a' tags. saved as a pdf in working directory
########################################
scatterandhistos <- function(data=NULL,x=NULL,y=NULL,bins=10){

# assign parameter defaults
if (is.null(data) | is.null(x) | is.null(y)) {
  data <- iris
  x <- "Petal.Length"
  y <- "Petal.Width"

}
# bins <- 10
# function body

  colnames(data)[colnames(data)==paste(x)] <- "x"
  colnames(data)[colnames(data)==paste(y)] <- "y"

  p1 <- ggplot(data,aes(x=x,y=y)) + geom_point() + geom_smooth(method = "lm", se = FALSE, color = "slateblue3") + theme_minimal() + labs(x = paste(x), y = paste(y))

  p2 <- ggplot(data, aes(x=x)) + geom_histogram(bins = bins,color = "black", fill = "lightblue1") + theme_minimal() + labs(x = paste(x))

  p3 <- ggplot(data, aes(y=y)) + geom_histogram(bins = bins, color = "black", fill = "lightgoldenrodyellow") + theme_minimal() + labs(y = paste(y))

  final <- print(p1/(p2 | (p3 + coord_flip())) + plot_annotation(tag_levels ="a", title = paste("Scatterplot of",x,"vs.",y,"and their respective histograms",sep=" ")))

  ggsave(filename = "ScatterplotAndHistograms.pdf",
         plot=final,
         device="pdf",
         width = 30,
         height = 20,
         units = "cm",
         dpi = 300)

  return(paste("Your plot is saved as 'ScatterplotAndHistograms.pdf'."))

} # end of function scatterandhistos
# --------------------------------------
# scatterandhistos()

scatterandhistos()

