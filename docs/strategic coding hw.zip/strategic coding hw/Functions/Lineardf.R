# --------------------------------------
# FUNCTION lineardf
# required packages: none
# description: runs a linear regression between two continuous columns in a dataframe and returns the summary stats as a data frame
# inputs: a data frame and two column names for x and y
# outputs: data frame with summary statistics
########################################
lineardf <- function(data = NULL, x = NULL, y = NULL){

# assign parameter defaults
if (is.null(data)) {
  data <- iris
}

if (is.null(x) | is.null(y)) {
  x <- 'Sepal.Length'
  y <- 'Sepal.Width'
}

  colnames(data)[colnames(data)==paste(x)] <- "x"
  colnames(data)[colnames(data)==paste(y)] <- "y"

# function body
m <- lm(x~y, data=data)
coefficients <- data.frame(summary(m)$coefficients)
rownames(coefficients) <- c("intectept",paste(y))

return(print(coefficients))

} # end of function lineardf
# --------------------------------------
# lineardf()


lineardf()
