# --------------------------------------
# FUNCTION statsbygroup
# required packages: dplyr
# description: will create a data frame with abundance and richness stats from a long format data frame
# inputs: 1. data = a long form data frame (must have one column containing species names and one with years (or month or any other group). 2. species = a character string which is the name of your species name column. 3. group = a character string which is the name of the column you'd like each stat calculated for. NOTE*** you must have an input for each otherwise it will calculate iris data by year.
# outputs: A data frame with one column for year, abundance, and richness
########################################
statsbygroup <- function(data=NULL,species=NULL,group=NULL){


if (is.null(data) | is.null(species) | is.null(group)) {
  data <- iris
  data <- data[sample(nrow(data)),]
  data <- mutate(data, group = rep(c('2020','2021','2022','2023','2024'), each=30))
  colnames(data)[5] <- "species"
  colnames(data)[6] <- "group"

}
else {
  colnames(data)[colnames(data)==paste(group)] <- "group"
  colnames(data)[colnames(data)==paste(species)] <- "species"
}


  a <- data%>%count(group) #idk why this works and count(Data$Year) doesnt but hey something works
  colnames(a)[1] <- "g"
# i <- 1
for (i in 1:nrow(a)) {
  if (i==1) {

    SummaryStats <- data.frame(matrix(ncol=3,nrow=0))
  }



  c <- sum(data$group==(a$g[i])) #to find abundance for a given year
  c <- as.numeric(c)
  b <- data%>%
    filter(group==(a$g[i]))%>%
    count(species)
  b <- nrow(b)
  b <- as.numeric(b)
  SummaryStats <- rbind(SummaryStats, data.frame(b,c,a$g[i]))



  if (i==nrow(a)) {
    colnames(SummaryStats) <- c('Richness','Abundance','Year')
  }


}



return(print(SummaryStats))

} # end of function statsbygroup
# --------------------------------------
# statsbygroup()




sum <- statsbygroup()
str(sum)



